# AllBot
Bot feito com: NodeJS + MySql - Biblioteca: DiscordJS (v13)<br>
